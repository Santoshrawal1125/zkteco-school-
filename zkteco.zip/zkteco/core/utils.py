from .models import Attendance, Staff, Student, Device, SchoolAdmin
from django.utils.timezone import make_aware
import datetime
from fcm.send_fcm import send_fcm_notification


def process_attendance_data(post_data, device_sn):
    device = Device.objects.filter(serial_number=device_sn).first()
    if not device:
        print(f"Device with SN {device_sn} not found.")
        return

    lines = post_data.strip().split('\n')

    for line in lines:
        parts = line.strip().split('\t')
        if len(parts) < 2:
            continue

        user_id = parts[0]
        timestamp_str = parts[1]
        status = parts[2] if len(parts) > 2 else '0'

        try:
            # Try Staff first
            user_obj = None
            user_type = None
            try:
                user_obj = Staff.objects.get(user__id=user_id)
                user_type = 'staff'
            except Staff.DoesNotExist:
                user_obj = Student.objects.get(user__id=user_id)
                user_type = 'student'

            raw_dt = datetime.datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
            arrival_time = make_aware(raw_dt.replace(microsecond=0))

            existing = Attendance.objects.filter(
                staff=user_obj if user_type == 'staff' else None,
                student=user_obj if user_type == 'student' else None,
                arrival_time=arrival_time
            ).first()

            if existing:
                print(f"⏩ Duplicate entry found for {user_type} ID {user_obj.id} at {arrival_time}, skipping.")
                if status == '1':  # punch-out
                    existing.departure_time = arrival_time
                    existing.save()
            else:
                att = Attendance.objects.create(
                    attendee_type=user_type,
                    staff=user_obj if user_type == 'staff' else None,
                    student=user_obj if user_type == 'student' else None,
                    arrival_time=arrival_time,
                    device=device,
                    department=user_obj.department if user_type == 'staff' else None,
                    school=user_obj.school
                )
                print(f"✅ Attendance saved: {att}")

                # Notify staff/student
                if user_obj.fcm_token:
                    message = f"{user_obj.user.get_full_name()} checked in at {arrival_time.strftime('%H:%M:%S')}"
                    send_fcm_notification(
                        token=user_obj.fcm_token,
                        title="🕒 Attendance Logged",
                        body=message
                    )

                # Notify all admins of the school
                school_admins = SchoolAdmin.objects.filter(school=user_obj.school)
                for admin in school_admins:
                    if admin.fcm_token:
                        admin_message = f"{user_type.title()} {user_obj.user.get_full_name()} checked in at {arrival_time.strftime('%H:%M:%S')}"
                        send_fcm_notification(
                            token=admin.fcm_token,
                            title="📢 Attendance Alert",
                            body=admin_message
                        )

        except (Staff.DoesNotExist, Student.DoesNotExist):
            print(f"❌ User with ID {user_id} not found as staff or student.")
