import firebase_admin
from firebase_admin import credentials, messaging
import os

# Load the service account credentials (load only once)
if not firebase_admin._apps:
    cred_path = os.path.join(os.path.dirname(__file__), 'firebase_credentials.json')
    cred = credentials.Certificate(cred_path)
    firebase_admin.initialize_app(cred)


def send_fcm_notification(token, title, body):
    try:
        message = messaging.Message(
            notification=messaging.Notification(
                title=title,
                body=body
            ),
            token=token
        )

        response = messaging.send(message)
        print(f"✅ Notification sent: {response}")

    except Exception as e:
        print(f"❌ Failed to send notification: {e}")
